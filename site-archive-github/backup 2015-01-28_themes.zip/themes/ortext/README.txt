This is the Ortext theme for a WordPress installation.
It was designed to be used with the Communicating with Prisoners ortext available at http://acrosswalls.org
See the header of style.css for further information.
