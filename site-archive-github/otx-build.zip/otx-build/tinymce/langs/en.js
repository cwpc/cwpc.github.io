tinyMCE.addI18n('en.otxlink',{
makeLink:"make ortext link"
});